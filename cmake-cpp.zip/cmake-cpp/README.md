# cmake-cpp-project

This is a blank template for making a C++ project in cmake